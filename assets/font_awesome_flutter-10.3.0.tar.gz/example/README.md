This package includes an example flutter project. To view it, please go to https://github.com/brianegan/font_awesome_flutter/tree/master/example
